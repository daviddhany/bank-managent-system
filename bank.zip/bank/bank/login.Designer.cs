﻿namespace bank
{
    partial class login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panel1 = new Panel();
            loginbtn = new Button();
            cancelbtn = new Button();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            loginyafta = new Label();
            txtpass = new TextBox();
            txtuser = new TextBox();
            passwords = new Label();
            username = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.MidnightBlue;
            panel1.Controls.Add(loginbtn);
            panel1.Controls.Add(cancelbtn);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(loginyafta);
            panel1.Controls.Add(txtpass);
            panel1.Controls.Add(txtuser);
            panel1.Controls.Add(passwords);
            panel1.Controls.Add(username);
            panel1.Location = new Point(12, 12);
            panel1.Name = "panel1";
            panel1.Size = new Size(1096, 557);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // loginbtn
            // 
            loginbtn.BackColor = Color.Olive;
            loginbtn.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginbtn.ForeColor = Color.Black;
            loginbtn.Location = new Point(213, 390);
            loginbtn.Name = "loginbtn";
            loginbtn.Size = new Size(128, 55);
            loginbtn.TabIndex = 8;
            loginbtn.Text = "&Login";
            loginbtn.UseVisualStyleBackColor = false;
            loginbtn.Click += loginbtn_Click;
            // 
            // cancelbtn
            // 
            cancelbtn.BackColor = Color.Olive;
            cancelbtn.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold);
            cancelbtn.ForeColor = SystemColors.ControlText;
            cancelbtn.Location = new Point(385, 390);
            cancelbtn.Name = "cancelbtn";
            cancelbtn.Size = new Size(128, 55);
            cancelbtn.TabIndex = 7;
            cancelbtn.Text = "&Cancel";
            cancelbtn.UseVisualStyleBackColor = false;
            cancelbtn.Click += cancelbtn_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.MidnightBlue;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(192, 0, 0);
            label3.Location = new Point(213, 322);
            label3.Name = "label3";
            label3.Size = new Size(0, 28);
            label3.TabIndex = 6;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.bank_PNG51;
            pictureBox1.Location = new Point(691, 113);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(365, 268);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // loginyafta
            // 
            loginyafta.AutoSize = true;
            loginyafta.Font = new Font("Segoe UI", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginyafta.ForeColor = Color.Olive;
            loginyafta.Location = new Point(29, 0);
            loginyafta.Name = "loginyafta";
            loginyafta.Size = new Size(210, 81);
            loginyafta.TabIndex = 4;
            loginyafta.Text = "Login ";
            loginyafta.Click += label3_Click;
            // 
            // txtpass
            // 
            txtpass.BackColor = Color.MintCream;
            txtpass.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold);
            txtpass.Location = new Point(213, 250);
            txtpass.MaxLength = 10;
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(300, 38);
            txtpass.TabIndex = 2;
            txtpass.UseSystemPasswordChar = true;
            txtpass.TextChanged += txtpass_TextChanged;
            // 
            // txtuser
            // 
            txtuser.BackColor = Color.MintCream;
            txtuser.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtuser.Location = new Point(213, 132);
            txtuser.MaxLength = 10;
            txtuser.Name = "txtuser";
            txtuser.Size = new Size(300, 38);
            txtuser.TabIndex = 2;
            txtuser.Tag = "";
            txtuser.TextChanged += txtuser_TextChanged;
            // 
            // passwords
            // 
            passwords.AutoSize = true;
            passwords.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            passwords.ForeColor = Color.Olive;
            passwords.Location = new Point(55, 250);
            passwords.Name = "passwords";
            passwords.Size = new Size(150, 41);
            passwords.TabIndex = 1;
            passwords.Text = "Password";
            // 
            // username
            // 
            username.AutoSize = true;
            username.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            username.ForeColor = Color.Olive;
            username.Location = new Point(47, 127);
            username.Name = "username";
            username.Size = new Size(158, 41);
            username.TabIndex = 0;
            username.Text = "Username";
            username.Click += label1_Click;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 5000;
            timer1.Tick += timer1_Tick;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1120, 581);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label passwords;
        private Label username;
        private TextBox txtpass;
        private TextBox txtuser;
        private Label loginyafta;
        private PictureBox pictureBox1;
        private Label label3;
        private System.Windows.Forms.Timer timer1;
        private Button cancelbtn;
        private Button loginbtn;
    }
}

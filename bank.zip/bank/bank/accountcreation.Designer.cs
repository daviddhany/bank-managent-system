﻿namespace bank
{
    partial class accountcreation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            customer = new TabControl();
            customerPage1 = new TabPage();
            label8 = new Label();
            label7 = new Label();
            txtemail = new TextBox();
            txtphone = new TextBox();
            txtname = new TextBox();
            email = new Label();
            phone = new Label();
            name = new Label();
            acountpage = new TabPage();
            txtacctype = new ComboBox();
            txtbal = new TextBox();
            txtidaccount = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label1 = new Label();
            savebtn = new Button();
            exitbtn = new Button();
            accidtxt = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            comboBox1 = new ComboBox();
            customer.SuspendLayout();
            customerPage1.SuspendLayout();
            acountpage.SuspendLayout();
            SuspendLayout();
            // 
            // customer
            // 
            customer.Controls.Add(customerPage1);
            customer.Controls.Add(acountpage);
            customer.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            customer.Location = new Point(-4, -2);
            customer.Name = "customer";
            customer.SelectedIndex = 0;
            customer.Size = new Size(589, 585);
            customer.TabIndex = 0;
            customer.TabStop = false;
            // 
            // customerPage1
            // 
            customerPage1.BackColor = Color.MidnightBlue;
            customerPage1.Controls.Add(label8);
            customerPage1.Controls.Add(label7);
            customerPage1.Controls.Add(txtemail);
            customerPage1.Controls.Add(txtphone);
            customerPage1.Controls.Add(txtname);
            customerPage1.Controls.Add(email);
            customerPage1.Controls.Add(phone);
            customerPage1.Controls.Add(name);
            customerPage1.Location = new Point(4, 32);
            customerPage1.Name = "customerPage1";
            customerPage1.Padding = new Padding(3);
            customerPage1.Size = new Size(581, 549);
            customerPage1.TabIndex = 0;
            customerPage1.Text = "customer";
            customerPage1.Click += customerPage1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label8.ForeColor = Color.FromArgb(192, 192, 0);
            label8.Location = new Point(216, 33);
            label8.Name = "label8";
            label8.Size = new Size(70, 28);
            label8.TabIndex = 3;
            label8.Text = "label8";
            label8.Click += label8_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label7.ForeColor = Color.FromArgb(192, 192, 0);
            label7.Location = new Point(46, 33);
            label7.Name = "label7";
            label7.Size = new Size(127, 28);
            label7.TabIndex = 2;
            label7.Text = "customer ID";
            label7.Click += label7_Click;
            // 
            // txtemail
            // 
            txtemail.Location = new Point(133, 405);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(375, 30);
            txtemail.TabIndex = 1;
            // 
            // txtphone
            // 
            txtphone.Location = new Point(133, 285);
            txtphone.Name = "txtphone";
            txtphone.Size = new Size(375, 30);
            txtphone.TabIndex = 1;
            // 
            // txtname
            // 
            txtname.Location = new Point(133, 165);
            txtname.Name = "txtname";
            txtname.Size = new Size(375, 30);
            txtname.TabIndex = 1;
            // 
            // email
            // 
            email.AutoSize = true;
            email.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            email.ForeColor = Color.FromArgb(192, 192, 0);
            email.Location = new Point(39, 405);
            email.Name = "email";
            email.Size = new Size(64, 28);
            email.TabIndex = 0;
            email.Text = "Email";
            email.Click += email_Click;
            // 
            // phone
            // 
            phone.AutoSize = true;
            phone.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            phone.ForeColor = Color.FromArgb(192, 192, 0);
            phone.Location = new Point(39, 285);
            phone.Name = "phone";
            phone.Size = new Size(71, 28);
            phone.TabIndex = 0;
            phone.Text = "Phone";
            // 
            // name
            // 
            name.AutoSize = true;
            name.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            name.ForeColor = Color.FromArgb(192, 192, 0);
            name.Location = new Point(39, 165);
            name.Name = "name";
            name.Size = new Size(68, 28);
            name.TabIndex = 0;
            name.Text = "Name";
            name.Click += name_Click;
            // 
            // acountpage
            // 
            acountpage.BackColor = Color.MidnightBlue;
            acountpage.Controls.Add(txtacctype);
            acountpage.Controls.Add(txtbal);
            acountpage.Controls.Add(txtidaccount);
            acountpage.Controls.Add(label6);
            acountpage.Controls.Add(label5);
            acountpage.Controls.Add(label1);
            acountpage.Location = new Point(4, 32);
            acountpage.Name = "acountpage";
            acountpage.Padding = new Padding(3);
            acountpage.Size = new Size(581, 549);
            acountpage.TabIndex = 1;
            acountpage.Text = "accountpage";
            // 
            // txtacctype
            // 
            txtacctype.FormattingEnabled = true;
            txtacctype.Items.AddRange(new object[] { "Saving", "Fix" });
            txtacctype.Location = new Point(182, 227);
            txtacctype.Name = "txtacctype";
            txtacctype.Size = new Size(323, 31);
            txtacctype.TabIndex = 5;
            txtacctype.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // txtbal
            // 
            txtbal.Location = new Point(182, 388);
            txtbal.Name = "txtbal";
            txtbal.Size = new Size(323, 30);
            txtbal.TabIndex = 4;
            // 
            // txtidaccount
            // 
            txtidaccount.Location = new Point(182, 54);
            txtidaccount.Name = "txtidaccount";
            txtidaccount.Size = new Size(323, 30);
            txtidaccount.TabIndex = 3;
            txtidaccount.TextChanged += textBox1_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label6.ForeColor = Color.FromArgb(192, 192, 0);
            label6.Location = new Point(12, 388);
            label6.Name = "label6";
            label6.Size = new Size(97, 31);
            label6.TabIndex = 2;
            label6.Text = "Balance";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(192, 192, 0);
            label5.Location = new Point(12, 227);
            label5.Name = "label5";
            label5.Size = new Size(159, 31);
            label5.TabIndex = 1;
            label5.Text = "Account Type";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(192, 192, 0);
            label1.Location = new Point(12, 54);
            label1.Name = "label1";
            label1.Size = new Size(133, 31);
            label1.TabIndex = 0;
            label1.Text = "Account ID";
            // 
            // savebtn
            // 
            savebtn.BackColor = Color.Olive;
            savebtn.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            savebtn.Location = new Point(718, 164);
            savebtn.Name = "savebtn";
            savebtn.Size = new Size(228, 97);
            savebtn.TabIndex = 1;
            savebtn.Text = "&Save";
            savebtn.UseVisualStyleBackColor = false;
            savebtn.Click += savebtn_Click;
            // 
            // exitbtn
            // 
            exitbtn.BackColor = Color.Olive;
            exitbtn.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            exitbtn.Location = new Point(718, 396);
            exitbtn.Name = "exitbtn";
            exitbtn.Size = new Size(228, 97);
            exitbtn.TabIndex = 1;
            exitbtn.Text = "&Back";
            exitbtn.UseVisualStyleBackColor = false;
            exitbtn.Click += exitbtn_Click;
            // 
            // accidtxt
            // 
            accidtxt.Location = new Point(171, 81);
            accidtxt.Name = "accidtxt";
            accidtxt.Size = new Size(375, 27);
            accidtxt.TabIndex = 9;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.ForeColor = Color.Olive;
            label2.Location = new Point(12, 321);
            label2.Name = "label2";
            label2.Size = new Size(86, 28);
            label2.TabIndex = 3;
            label2.Text = "Balance";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.ForeColor = Color.Olive;
            label3.Location = new Point(12, 202);
            label3.Name = "label3";
            label3.Size = new Size(138, 28);
            label3.TabIndex = 4;
            label3.Text = "Account type";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label4.ForeColor = Color.Olive;
            label4.Location = new Point(12, 81);
            label4.Name = "label4";
            label4.Size = new Size(117, 28);
            label4.TabIndex = 5;
            label4.Text = "Account ID";
            label4.Click += label4_Click;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Saving ", "Fix" });
            comboBox1.Location = new Point(171, 206);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(375, 28);
            comboBox1.TabIndex = 10;
            // 
            // accountcreation
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(1120, 574);
            Controls.Add(exitbtn);
            Controls.Add(savebtn);
            Controls.Add(customer);
            FormBorderStyle = FormBorderStyle.None;
            Name = "accountcreation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "accountcreation";
            Load += accountcreation_Load;
            customer.ResumeLayout(false);
            customerPage1.ResumeLayout(false);
            customerPage1.PerformLayout();
            acountpage.ResumeLayout(false);
            acountpage.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl customer;
        private TabPage customerPage1;
        private TabPage tabPage2;
        private Label email;
        private Label phone;
        private Label name;
        private TextBox txtemail;
        private TextBox txtphone;
        private TextBox txtname;
        private TextBox txtidaccount;
        private TextBox txtbal;
        private TextBox textBox3;
        private TextBox accidtxt;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button savebtn;
        private Button exitbtn;
        private ComboBox comboBox1;
        private TabPage acountpage;
        private ComboBox txtacctype;
        private Label label6;
        private Label label5;
        private Label label8;
        private Label label7;
    }
}
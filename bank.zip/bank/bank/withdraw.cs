﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace bank
{
    public partial class withdraw : Form
    {
        public withdraw()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("server=localhost ; database= pobank ; username=root ; password= ;");

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string str = "select * from account where accid = '" + accid.Text + "'";
                MySqlCommand cmd = new MySqlCommand(str, con);
                MySqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    txtbal.Text = dr[3].ToString();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void wthbtn_Click(object sender, EventArgs e)
        {
            string accno;
            double bal, withdraw;
            accno = accid.Text;
            bal = double.Parse(txtbal.Text);
            withdraw = double.Parse(txtwth.Text);
            if (withdraw > bal)
            { MessageBox.Show("no fund"); }
            else
            {


                con.Open();
                MySqlCommand cmd = new MySqlCommand();
                MySqlTransaction transaction;
                transaction = con.BeginTransaction();
                cmd.Connection = con;
                cmd.Transaction = transaction;

                try
                {
                    cmd.CommandText = "update account set balance= balance - '" + withdraw + "' where accid= '" + accno + "'";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "insert into transaction(accid,balance,withdraw) values('" + accno + "','" + bal + "','" + withdraw + "')";
                    cmd.ExecuteNonQuery();

                    transaction.Commit();
                    MessageBox.Show("transaction success");

                }

                catch (Exception ex)
                {
                    transaction.Rollback();
                    MessageBox.Show(ex.ToString());

                }
                finally
                {
                    Main main = new Main();
                    this.Close();
                    main.Show();
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            this.Close();
            main.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}

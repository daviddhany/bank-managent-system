namespace bank
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }
        int count;

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void txtuser_TextChanged(object sender, EventArgs e)
        {

        }




        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            string username, password;
            username = txtuser.Text;
            password = txtpass.Text;
            count++;
            if (count > 5)
            {
                MessageBox.Show("system has been blocked.....");
                Application.Exit();
            }
            if (username == "" && password == "")
            { label3.Text = "enter username and password"; }

            else if (username.Length >= 10 || password.Length >= 10)
            {
                label3.Text = "should be shorter than 10 characters";
            }
            else
            {


                if (username == "admin" && password == "1234")
                {
                    //label3.Text = "successfully logged in";
                    progrbar pr = new progrbar();
                    this.Hide();
                    pr.Show();
                }
                else
                {
                    label3.Text = "Invalid username or password";
                    txtuser.Clear();
                    txtpass.Clear();
                    txtuser.Focus();
                }
            }
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }




        // private void timer_1=
    }
}

﻿namespace bank
{
    partial class progrbar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            progressBar1 = new ProgressBar();
            loadingbvar = new Label();
            loadingtimer = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(138, 136);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(493, 37);
            progressBar1.TabIndex = 0;
            // 
            // loadingbvar
            // 
            loadingbvar.AutoSize = true;
            loadingbvar.BackColor = Color.MidnightBlue;
            loadingbvar.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loadingbvar.ForeColor = Color.Olive;
            loadingbvar.Location = new Point(315, 191);
            loadingbvar.Name = "loadingbvar";
            loadingbvar.Size = new Size(140, 38);
            loadingbvar.TabIndex = 1;
            loadingbvar.Text = "loading...";
            // 
            // loadingtimer
            // 
            loadingtimer.Enabled = true;
            loadingtimer.Tick += loadingtimer_Tick;
            // 
            // progrbar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(790, 318);
            Controls.Add(loadingbvar);
            Controls.Add(progressBar1);
            ForeColor = SystemColors.ControlText;
            FormBorderStyle = FormBorderStyle.None;
            Name = "progrbar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "progrbar";
            Load += progrbar_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ProgressBar progressBar1;
        private Label loadingbvar;
        private System.Windows.Forms.Timer loadingtimer;
    }
}
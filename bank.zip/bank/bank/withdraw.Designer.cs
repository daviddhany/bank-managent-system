﻿namespace bank
{
    partial class withdraw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox2 = new GroupBox();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            wthbtn = new Button();
            button1 = new Button();
            txtwth = new TextBox();
            txtbal = new TextBox();
            accid = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.MidnightBlue;
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(pictureBox1);
            groupBox2.Controls.Add(wthbtn);
            groupBox2.Controls.Add(button1);
            groupBox2.Controls.Add(txtwth);
            groupBox2.Controls.Add(txtbal);
            groupBox2.Controls.Add(accid);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.FlatStyle = FlatStyle.Flat;
            groupBox2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.ForeColor = Color.Olive;
            groupBox2.Location = new Point(9, 13);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(772, 540);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Withdraw";
            groupBox2.Enter += groupBox1_Enter;
            // 
            // button2
            // 
            button2.BackColor = Color.Olive;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.Black;
            button2.Location = new Point(651, 42);
            button2.Name = "button2";
            button2.Size = new Size(103, 54);
            button2.TabIndex = 9;
            button2.Text = "&back";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.download_dollar_sign_symbols_png_transparent_images_12;
            pictureBox1.Location = new Point(555, 174);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(199, 182);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // wthbtn
            // 
            wthbtn.BackColor = Color.Olive;
            wthbtn.FlatStyle = FlatStyle.Flat;
            wthbtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            wthbtn.ForeColor = Color.Black;
            wthbtn.Location = new Point(391, 466);
            wthbtn.Name = "wthbtn";
            wthbtn.Size = new Size(130, 47);
            wthbtn.TabIndex = 7;
            wthbtn.Text = "&Withdraw";
            wthbtn.UseVisualStyleBackColor = false;
            wthbtn.Click += wthbtn_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.Olive;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(218, 466);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 7;
            button1.Text = "&Search";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txtwth
            // 
            txtwth.Location = new Point(218, 341);
            txtwth.Name = "txtwth";
            txtwth.Size = new Size(303, 43);
            txtwth.TabIndex = 6;
            // 
            // txtbal
            // 
            txtbal.Location = new Point(218, 221);
            txtbal.Name = "txtbal";
            txtbal.Size = new Size(303, 43);
            txtbal.TabIndex = 5;
            // 
            // accid
            // 
            accid.Location = new Point(218, 101);
            accid.Name = "accid";
            accid.Size = new Size(303, 43);
            accid.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label3.ForeColor = Color.Olive;
            label3.Location = new Point(42, 215);
            label3.Name = "label3";
            label3.Size = new Size(97, 31);
            label3.TabIndex = 2;
            label3.Text = "Balance";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label2.ForeColor = Color.Olive;
            label2.Location = new Point(42, 335);
            label2.Name = "label2";
            label2.Size = new Size(120, 31);
            label2.TabIndex = 1;
            label2.Text = "WIthdraw";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label1.ForeColor = Color.Olive;
            label1.Location = new Point(42, 95);
            label1.Name = "label1";
            label1.Size = new Size(90, 31);
            label1.TabIndex = 0;
            label1.Text = "Acc No";
            // 
            // withdraw
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(790, 567);
            Controls.Add(groupBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "withdraw";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "withdraw";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox2;
        private PictureBox pictureBox1;
        private Button wthbtn;
        private Button button1;
        private TextBox txtwth;
        private TextBox txtbal;
        private TextBox accid;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button2;
    }
}
﻿namespace bank
{
    partial class deposit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            pictureBox1 = new PictureBox();
            depositbtn = new Button();
            button1 = new Button();
            txtdep = new TextBox();
            txtbal = new TextBox();
            accid = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            button2 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.MidnightBlue;
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(pictureBox1);
            groupBox1.Controls.Add(depositbtn);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(txtdep);
            groupBox1.Controls.Add(txtbal);
            groupBox1.Controls.Add(accid);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.Olive;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(772, 540);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Deposit";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.download_dollar_sign_symbols_png_transparent_images_12;
            pictureBox1.Location = new Point(555, 174);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(199, 182);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            // 
            // depositbtn
            // 
            depositbtn.BackColor = Color.Olive;
            depositbtn.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            depositbtn.ForeColor = Color.Black;
            depositbtn.Location = new Point(415, 466);
            depositbtn.Name = "depositbtn";
            depositbtn.Size = new Size(106, 47);
            depositbtn.TabIndex = 7;
            depositbtn.Text = "&Deposit";
            depositbtn.UseVisualStyleBackColor = false;
            depositbtn.Click += depositbtn_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.Olive;
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(218, 466);
            button1.Name = "button1";
            button1.Size = new Size(94, 47);
            button1.TabIndex = 7;
            button1.Text = "&Search";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txtdep
            // 
            txtdep.Location = new Point(218, 341);
            txtdep.Name = "txtdep";
            txtdep.Size = new Size(303, 43);
            txtdep.TabIndex = 6;
            // 
            // txtbal
            // 
            txtbal.Location = new Point(218, 221);
            txtbal.Name = "txtbal";
            txtbal.Size = new Size(303, 43);
            txtbal.TabIndex = 5;
            // 
            // accid
            // 
            accid.Location = new Point(218, 101);
            accid.Name = "accid";
            accid.Size = new Size(303, 43);
            accid.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label3.ForeColor = Color.Olive;
            label3.Location = new Point(42, 215);
            label3.Name = "label3";
            label3.Size = new Size(97, 31);
            label3.TabIndex = 2;
            label3.Text = "Balance";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label2.ForeColor = Color.Olive;
            label2.Location = new Point(42, 335);
            label2.Name = "label2";
            label2.Size = new Size(97, 31);
            label2.TabIndex = 1;
            label2.Text = "Deposit";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label1.ForeColor = Color.Olive;
            label1.Location = new Point(42, 95);
            label1.Name = "label1";
            label1.Size = new Size(90, 31);
            label1.TabIndex = 0;
            label1.Text = "Acc No";
            // 
            // button2
            // 
            button2.BackColor = Color.Olive;
            button2.ForeColor = Color.Black;
            button2.Location = new Point(625, 42);
            button2.Name = "button2";
            button2.Size = new Size(129, 57);
            button2.TabIndex = 9;
            button2.Text = "&Back";
            button2.UseCompatibleTextRendering = true;
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // deposit
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(797, 567);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "deposit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "deposit";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox txtdep;
        private TextBox txtbal;
        private TextBox accid;
        private Label label3;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox1;
        private Button depositbtn;
        private Button button1;
        private Button button2;
    }
}
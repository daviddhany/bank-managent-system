﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace bank
{
    public partial class progrbar : Form
    {
        public progrbar()
        {
            InitializeComponent();
        }

        private void loadingtimer_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = progressBar1.Value + 10;

            if (progressBar1.Value >= 99)
            {
                Main m = new Main();
                this.Hide();
                m.Show();
                loadingtimer.Enabled = false;
                progressBar1.Value = progressBar1.Value - 10;

            }
        }

        private void progrbar_Load(object sender, EventArgs e)
        {

        }
    }
}

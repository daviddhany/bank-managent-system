﻿namespace bank
{
    partial class transfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button3 = new Button();
            button2 = new Button();
            label2 = new Label();
            label3 = new Label();
            fromtxt = new TextBox();
            totxt = new TextBox();
            amounttxt = new TextBox();
            button1 = new Button();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.ForeColor = Color.FromArgb(192, 192, 0);
            groupBox1.Location = new Point(9, 8);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(553, 422);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Transfer";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // button3
            // 
            button3.BackColor = Color.Olive;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            button3.ForeColor = Color.Black;
            button3.Location = new Point(401, 132);
            button3.Name = "button3";
            button3.Size = new Size(116, 52);
            button3.TabIndex = 1;
            button3.Text = "&submit";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Olive;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(401, 244);
            button2.Name = "button2";
            button2.Size = new Size(116, 52);
            button2.TabIndex = 1;
            button2.Text = "&Back";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(192, 192, 0);
            label2.Location = new Point(44, 205);
            label2.Name = "label2";
            label2.Size = new Size(39, 31);
            label2.TabIndex = 2;
            label2.Text = "To";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(192, 192, 0);
            label3.Location = new Point(44, 321);
            label3.Name = "label3";
            label3.Size = new Size(102, 31);
            label3.TabIndex = 3;
            label3.Text = "Amount";
            // 
            // fromtxt
            // 
            fromtxt.Location = new Point(152, 95);
            fromtxt.Name = "fromtxt";
            fromtxt.Size = new Size(199, 27);
            fromtxt.TabIndex = 5;
            // 
            // totxt
            // 
            totxt.Location = new Point(152, 211);
            totxt.Name = "totxt";
            totxt.Size = new Size(199, 27);
            totxt.TabIndex = 6;
            // 
            // amounttxt
            // 
            amounttxt.Location = new Point(152, 327);
            amounttxt.Name = "amounttxt";
            amounttxt.Size = new Size(199, 27);
            amounttxt.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = Color.Olive;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(401, 138);
            button1.Name = "button1";
            button1.Size = new Size(116, 52);
            button1.TabIndex = 0;
            button1.Text = "&Transfer";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(192, 192, 0);
            label1.Location = new Point(44, 89);
            label1.Name = "label1";
            label1.Size = new Size(70, 31);
            label1.TabIndex = 1;
            label1.Text = "From";
            // 
            // transfer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.MidnightBlue;
            ClientSize = new Size(569, 437);
            Controls.Add(amounttxt);
            Controls.Add(totxt);
            Controls.Add(fromtxt);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "transfer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "transfer";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label3;
        private TextBox fromtxt;
        private TextBox totxt;
        private TextBox amounttxt;
        private Button button2;
        private Button button1;
        private Label label1;
        private Button button3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace bank
{
    public partial class accountcreation : Form
    {
        public accountcreation()
        {
            InitializeComponent();
        }
        MySqlConnection con = new MySqlConnection("server=localhost ; database= pobank ; username=root ; password= ;");

        public void custtid()
        {
            con.Open();
            string query = "select max(custid) from customer";
            MySqlCommand cmd = new MySqlCommand(query, con);
            MySqlDataReader dr;

            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                string val = dr[0].ToString();
                if (val == "")
                {
                    label8.Text = "10000";
                }
                else
                {
                    int a;
                    a = int.Parse(dr[0].ToString());
                    a = a + 1;
                    label8.Text = a.ToString();

                }
                con.Close();
            }

        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void name_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void accountcreation_Load(object sender, EventArgs e)
        {
            custtid();
        }

        private void savebtn_Click(object sender, EventArgs e)
        {
            string custid, name, email, phone, accid, acctype, balance;
            custid = label8.Text;
            name = txtname.Text;
            email = txtemail.Text;
            phone = txtphone.Text;


            accid = txtidaccount.Text;
            acctype = txtacctype.Text;
            balance = txtbal.Text;

            con.Open();
            MySqlCommand cmd = new MySqlCommand();
            MySqlTransaction transaction;
            transaction = con.BeginTransaction();
            cmd.Connection = con;
            cmd.Transaction = transaction;

            try
            {
                cmd.CommandText = "insert into customer(custid,name,email,phone) values('" + custid + "','" + name + "','" + email + "','" + phone + "')";
                cmd.ExecuteNonQuery();
                cmd.CommandText = "insert into account(accid,custid,acctype,balance) values('" + accid + "','" + custid + "','" + acctype + "','" + balance + "')";
                cmd.ExecuteNonQuery();

                transaction.Commit();
                MessageBox.Show("customer added");

            }

            catch (Exception ex)
            {
                transaction.Rollback();
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                con.Close();
            }
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void customerPage1_Click(object sender, EventArgs e)
        {

        }
    }
}
